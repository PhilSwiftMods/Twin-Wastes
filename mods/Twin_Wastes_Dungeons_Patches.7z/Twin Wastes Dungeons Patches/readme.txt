Merged the following patches:
From piber's patch and micro mod hell (fnvttw) https://www.nexusmods.com/newvegas/mods/77674:
AWOP Revised TTW
More Mojave TTW Extras
  -removed all edits to cells removed by Dark Side Edition
  -changes WastelandFungus to TTWGlowingStalks in MoreMojaveIvanpahAntMound
NV Interiors Remastered TTW Extras
NV Interiors Remastered No Dropboxes
NV Interiors Rmeastered No Pinups
---
Sweet Pain NV TTW Patch https://www.nexusmods.com/newvegas/mods/81523
---
Easy To Find Hidden Valley Bunker - ETFHVB https://www.nexusmods.com/newvegas/mods/79445


Open permissions