Merged the following patches:
From piber's patch and micro mod hell (fnvttw) https://www.nexusmods.com/newvegas/mods/77674:
AWOP Revised TTW
More Mojave TTW Extras
  -removed all edits to cells removed by Dark Side Edition
  -changes WastelandFungus to TTWGlowingStalks in MoreMojaveIvanpahAntMound
NV Interiors Remastered TTW Extras
NV Interiors Remastered No Dropboxes
NV Interiors Rmeastered No Pinups
---
Sweet Pain NV TTW Patch https://www.nexusmods.com/newvegas/mods/81523
---
Easy To Find Hidden Valley Bunker - ETFHVB https://www.nexusmods.com/newvegas/mods/79445
---
https://www.nexusmods.com/newvegas/mods/91060
More Mojave DSE - FPGE Patch
More Mojave DSE - Mojave Scenery Patch
---
https://www.nexusmods.com/newvegas/mods/70165
TGMIO - FPGE Patch
TGMIO - TLD Patch
---
https://www.nexusmods.com/newvegas/mods/74391
Home and Safehouse Tweaks - TGMIO Patch
---
https://www.nexusmods.com/newvegas/mods/70419
Stars Turned Face Up
  -patched for The Great Mojave Interior Overhaul

Open permissions