Merged the following files:
https://www.nexusmods.com/newvegas/mods/75031
Better Brotherhood's TTW Patch
Better Brotherhood's FPGE Patch
https://www.nexusmods.com/newvegas/mods/85216
Better Brotherhood - No Infamy for Selling