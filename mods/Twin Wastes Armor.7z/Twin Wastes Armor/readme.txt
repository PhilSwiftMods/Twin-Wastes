Merge of the following armor mods:
Classic Fallout Metal Armor
Classic Fallout 2 Metal Armor MKII
Armored Vault 21 Jumpsuit - Armored Vault 21 Jump Suit Replacer:
  -removed spawn from Doc Mitchell's house
Classic Combat Armor Replacer
  -replaced Desert Combat Armor spawn as it has bugged texture
  -removed Lucky Battle Helmet spawn
Classic Fallout 2 Combat Armor MK2
Classic Combat Armor Replacer Redux TTW
Tweaks for TTW - Combat Armors Replacer
Vikki's Bonnet and Vance's Lucky Hat - +1 LK:
  -left spawn in the Wins' safe in case you don't want to kill them
Unique Courier Dusters:
  -removed the cheat container outside of Canyon Wreckage
Courier Duster with Elite Riot Gear combo
  -must be crafted with your (or Ulysses') Duster + Elite Riot Gear
  -rebalanced for TTW and Lone Star
Classic Leather Armors Non-Replacers:
  -integrated into Mojave leveled lists and as recipes
  -TTW JSawyer Rebalanced version used
Veronica Outfit Replacer - Scavenger:
  -made her hood and robes playable so they can be removed (so she'll actually wear that dress you give her)
  -reverted stat changes
  -also made Cass's hat playable so it can be removed
Jason Bright Head Seam Concealer (Jason Wears a Bandana)
Another Millenia Shop Add-On Vanilla Armors
  -for compatibility with Classic Combat Armors and Physically Based Rangers (included in SALVO)
Ugly Armor Gloves Remover
White Gloves Have White Gloves Improved Edition
Lore Friendly 1st Recon
  -NPC Overhaul version used
  -Hunting Rifle and Friends patch integrated

Patched for Lone Star and TTW