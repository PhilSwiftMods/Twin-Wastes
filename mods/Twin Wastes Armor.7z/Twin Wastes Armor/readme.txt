Merge of the following armor mods:
Classic Fallout Metal Armor
Classic Fallout 2 Metal Armor MKII
Armored Vault 21 Jumpsuit - Armored Vault 21 Jump Suit Replacer:
  -removed spawn from Doc Mitchell's house
Classic Combat Armor Replacer
Classic Fallout 2 Combat Armor MK2
Classic Combat Armor Replacer Redux TTW
Tweaks for TTW - Combat Armors Replacer
Vikki's Bonnet and Vance's Lucky Hat - +1 LK:
  -left spawn in the Wins' safe in case you don't want to kill them
Unique Courier Dusters:
  -removed the cheat container outside of Canyon Wreckage

Patched for Lone Star and TTW