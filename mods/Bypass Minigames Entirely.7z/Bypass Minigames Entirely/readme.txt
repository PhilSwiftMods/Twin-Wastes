Config for Bypass Minigames ESPLess that should bypass minigames entirely:
Skip minigame key set to 'E' (default use key)
Bobby pin not removed
XP given