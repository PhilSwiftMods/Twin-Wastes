Merge of the following mods:
Tale of Two Wastelands Quick Start https://www.nexusmods.com/newvegas/mods/65937
TTW Quick Start Item Remover https://www.nexusmods.com/newvegas/mods/75832
TTW No Free Levelup https://www.nexusmods.com/newvegas/mods/82173
TTW Quick Start - Rock-It Launcher Schematics Remover https://www.nexusmods.com/newvegas/mods/82015
TTW Quick Train To NV Prompt https://www.nexusmods.com/newvegas/mods/82311
Wasteland Starting Gear DC https://www.nexusmods.com/newvegas/mods/75789

6 plugins felt excessive for just starting a new game.