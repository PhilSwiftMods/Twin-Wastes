RAD - Radiation (is) Actually Dangerous - Overhaul - with Injection Fix https://www.nexusmods.com/newvegas/mods/78077
RAD - Just Assorted Mods Patch https://www.nexusmods.com/newvegas/mods/77674

Merged into main RAD esp. Main RAD - Overhaul (https://www.nexusmods.com/newvegas/mods/71541) still required.