Type4 Plugin patched for:
TTW
Modest Replacers
Lone Star
Classic Fallout Metal Armor
Classic Fallout 2 Metal Armor MK II
