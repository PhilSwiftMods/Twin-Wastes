Merge of the following plugins:

ATMOS Sound Overhaul - TTW.esp https://www.nexusmods.com/newvegas/mods/84054
---
https://www.nexusmods.com/newvegas/mods/85939
ATMOS NV - TTW Patch
ATMOS NV - AWOP Revision
---
https://www.nexusmods.com/newvegas/mods/79005
ATMOS NV - FPGE Patch
ATMOS NV - ExRB Patch