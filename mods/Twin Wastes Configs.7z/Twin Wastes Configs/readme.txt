New Vegas Tick Fix (NVSE\Plugins\NVTF.ini)
  Set bModifyDirectXBehavior to 1 (NVTF default)
  Set bUseDefaultPoolForTextures to 1.
- as per the FNV Performance Guide

JIP Settings INI (nvse\plugins\jip_nvse.ini)
  Set bEnableFO3Repair=1
  Set bLocalizedDTDR=1
  Set bLoadScreenFix=1
  Set bNPCWeaponMods=1
  Set uWMChanceMin=5
  Set uWMChanceMax=30
  Set uNPCPerks=1
  Set bCreatureSpreadFix=1

B42 True Lean (config\B42Leaning\Settings.ini)
  -disabled contextual leaning
  -set lean keys to Q/E
  -set modifier key to 257 (leaning only works while aiming)

Pipboy Holo Panel ESPless (config\PipBoyHoloPanel.ini)
  -set to power armor only

Enhanced Movement (config\EnhancedMovement.ini)
  -set bUseINI=1
  -set iINISaveMode=0 (automatic)
  -set bSprintSwimming=1 (swimming sections suck and we all want to get them over with)
  -set bEnableProne=1
  -set bUseSneakKey=1 (hold CTRL to prone instead of crouch)
  -leaning disabled in favor of B42 True Lean

Quick Select (config\QuickSelect.ini)
  -set select keys to MB5 for weapons and MB4 for aid to avoid conflict with vanilla hotkeys
  -it's 2025, just get a gaming mouse already

Pipboy Holo Panel ESPless (config\PipBoyHoloPanel.ini)
  -set PowerArmorOnly=1

Securitrons on Alert (config\Securitrons On Alert.ini)
  Set bColorizedSecuritrons=1
  Set bScreenScanLines=1

Lone Star (config\Lone Star.ini):
  Used RuyN21's custom config.
  -set VanillaHP=1 due to Survival Mode damage
  -set iDisableDerangedBrightFollowers=1. bad for early game balance imo

Radio Script Runner (config\RadioEnabler.ini):
  -Enabled all radio stations
  -RNV always accessible in Capital Wasteland, in case you use mods that affect it

Just Mods Assorted/JAM (config\JustMods.ini):
  -configured hotkeys
  -Bullet time is 'B'
  -3D objective markers is ','
  -disabled Weapon Hweel (buggy)
  -disabled Just Spring in favor of Enhanced Movement
  
Customizable Integrated Backpack System (config\CIBS.ini)
  -disabled backpack conditions, low health + famine makes it annoying
  -reduced backpack spawns by 50% (you don't need many)

Famine (config\Famine.ini):
  -upped fArmorConditionMultiplier to .66 (up from .5)
  -upped fWeaponConditionMultiplier to .5 (up from .33)

Mojave Raiders Lite (config\Mojave Raiders Lite.ini):
  -disabled all added Fiends spawns as other mods also add them
  -will do a balance pass to re add some in the future

Contextual HUD (config\iHUD.ini):
  -set HUD to appear with weapon out

JIP CC&C (config\ccc_prefs.ini):
  -Disabled Anti-Overlap (prevents UI bugs)
  -Enabled Manage gear (right-click in their inventory)
  -Disabled draw with player (annoying with dogs)
  -Disabled Unlimited Companions (overpowered)
  -Disabled Skipping Companion Wheel (I like the wheel)

Benny Humbles You and Steals Your Stuff (config\Humbling.ini):
  -bCapRemoval=0, assuming Benny puts them in his safe
  -bPerkHumbleXP=0
  -bPerkHumbleHeadTrauma=0
  -


Weapon Packs:
Another Millenia (config\Another Millenia Config.ini):
Disabled the following weapons:
  -Service Revolver (WAP Police Pistol)
  -Police Submachine Gun/MP5 (ZL Armaments)
  -Sporting Pistol/1911 (Honest Hearts)
  -Mercenary Marksman Rifle/AS VAL (ZL Armaments)
  -Mercenary Sniper Rifle/SVD Dragunov (ZL Armaments)
  -Combat Shotgun and all uniques (Combat Shotgun and Friends)
  -Chinese Pistol/Mauser C96 (CFWR)
  -H&K CAWS (CFWR) (uniques enabled)
  -Desert Eagle (CFWR) (uniques enabled)
Enabled real weapon names.
Disabled cheat chest on Doc Mitchell's roof.

Another Millenia Add-on (config\Add-on Config.ini):
Disabled the following weapons:
  -Browning HP (vanilla 9mm)
  -ClassicM14
  -Classic1911
  -ClassicFAMAS
  -ClassicCAWS
  -1897 (Tactapack)
  -SPAS-153 (VIP Shotguns)
Enabled real weapon names.

Classic Fallout Weapons Remastered (config\CFWR Config.ini):
Disabled the following weapons and settings: 
  -Classic Sawed Off (Tactapack)
  -AK-112 (Tactapack)
  -Classic Sledgehammer (redundant)
  -Classic Sniper Rifle (DKS and Friends)
  -P90 (ZL Armaments)
  -P92 Plasma Caster (ugly)
  -P94 Plasma Caster (ugly and redundant with vanilla/GRA)
  -Tommy Gun (redundant)
  -XL70 (Another Millenia L85)
  -Alien Blaster (redundant/ugly)
  -M60 (ugly model)
  -Pancor Jackhammer (Another Millenia)
  -G11 (buggy with B42 Optics)
  -Solar Scorcher (Tactapack)
  -Pipe Rifle Legion Lists (shows up plenty at low levels without this setting)
  -Magnetic Dart Pistol (dislike multiple pistols with same model)
  -sNailAmmoContainerLoot (nails become ridiculously common)
Set names of unused to obvious variants vs real weapon names.
Set all weapons to use vanilla weapon mods.

Tactapack (config\Tactapack config.ini):
Disabled the following weapons:
  -Star Model B (vanilla 9mm)
  -AK112 (Classic AK-112 - The Adytum Rifle)
  -Mossberg 590 (vanilla Hunting Shotgun)
  -Winchester Model 70 (Hunting Rifle and Friends)
  -Webley (horribly slow reload)
Enabled real weapon names.

ZL Armaments Remastered (config\zl_armaments_config.ini):
Disabled most ACR variants as 1 full auto is closer to vanilla implementation
Enabled real weapon names. (default).

Hit - Explosives (config\Hit Explosives Config.ini):
  -Set real weapon names

SiouX Weapons Reloaded (config\Sioux Weapons.ini):
Disabled the following weapons:
  -M4 Benelli (VIP Shotguns)
Enabled real weapon names

VIP Shotguns (config\VIP - Shotguns Config.ini):
  -Renamed Cowboy Shotgun Model 1901 to avoid redundancy with WAP Lever Action
  -I made an exception because rule of cool
  -Set real weapon names via script in: nvse\plugins\scripts\gr_rwn_vip.txt

Nevada Arsenal (config\NevA Config.ini):
  -sRocketGrenadeDiscardRecipe=0 ; non-intuitive to the rest of vanilla. player may get confused and not want to destroy them permanently
  -sRenamingNoHandLoad=0 ; handled by Consistent Caliber Naming
  -sFlareGun=0 ; somewhat performance intensive with Energy Visuals Plus
  -sNailGun=0 ; bad for balance since Semi-Auto Nailgun Rework won't work with NVAO
  -sTeslaCannon=0 ; supposed to be a rare prototype
  -sBaseballBatCustom=0 ; redundant with TTW/Lone Star
  -sIndustrialHand=0 ; potentially bugged NPC anims
  -sProtonAxe=0 ; only fits in OWB imo
  -sProtonAxeThrowing=0 ; only fits in OWB imo
  -sScientistFist=0 ; only fits in OWB imo
  -sTomahawk=0 ; only fits with HH's tribal aesthetic
  -sWarClub=0 ; only fits with HH's tribal aesthetic
  -sFlashbang=0 ; only useful against LR Tunnelers
  -sNailAmmoVendorsAndAmmoLoot=0 ; handled by CFWR
  -sNailAmmoContainerLoot=0 ; handled by CFWR
  -sLRModsLowLevel=1 ; dislike CFWR's 4.7mm rebalance
  -sLRModsHighLevel=0

DC Arsenal (config\DC Arsenal Config.ini):
  -Unique Changes set to 0 for maximum compatibility:
    sBackwaterRifle=0
	sBlackBartsBane=0
	sVictoryRifle=0
	sSmugglersEnd=0
	sHeavyAssaultRifle=0
  -sCombatShotgun=0 ; FO3's loot pools are designed around 12 ga.
  -sJustEnoughRealism=0 ; if anything I've found 12 ga. to be more common
  -Railway Settings set to 0
    -it's meant to be a goofy unique weapon, imo.
	-sRailwayRepair=1 to make it more viable
  -Mojave to DC Integrations: only changes from default values listed
    -sSingleShotgun=1
    -sChainsawCondAutoAxe=1
	-sFlashbang=0 ; only useful against LR Tunnelers
	-sIndustrialHand=0 ; potentially bugged NPC anims
    -sNailGun=0 ; bad for balance since Semi-Auto Nailgun Rework won't work with NVAO
	-sPulseGun=0 ; supposed to be rare
	-sScientistGlove=0 ; only fits in OWB imo
  -DC to Mojave Integrations: only changes from default values listed
    -sAxeFire=0 ; Fire Axe has a better model
	-sDBShotgunHunting=1
	-sScoped44=0 ; ECEM disables this anyway
	-sTrenchKnifeCombat=1
	-